/**1 Pto si se ha mostrado un mensaje por la consola del navegador */
console.log('Esto esta escrito desde el fichero txt');

/**1 Pto si se ha añadido  contenido HTML con el atributo innerHTML. */
let html = document.getElementById("puntoD").innerHTML;
console.log(html);

alert("Hola Pablo");