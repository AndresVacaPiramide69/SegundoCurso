/**1 Pto si se ha generado código HTML usando el método write del objeto document. */
document.write("<a href='https://www.sportium.es'>Enlace de la vida</a>");