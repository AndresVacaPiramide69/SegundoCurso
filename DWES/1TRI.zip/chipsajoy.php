<?php

    echo "<h1>Esto es real chat???</h1>";
    echo "Hola moniciosJr";
    echo "<p>Hola gabin que tal estas</p>";
    
?>