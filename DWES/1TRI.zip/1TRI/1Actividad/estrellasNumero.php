<?php

$num_estrella = $_GET["numero"];

echo "<p>EL numero de estrellas es " . $num_estrella . "</p>";

for($i = 0; $i <= $num_estrella; $i++){

    for($j = 0; $j < $i; $j++){
        echo "*";
    }
    echo "<br></br>";
}
?>