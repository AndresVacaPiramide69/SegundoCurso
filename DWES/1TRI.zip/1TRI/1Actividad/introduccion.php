<?php
/**A) Muestra tu nombre usando echo */
echo("Andres Alejandro vaca");
echo "<br></br>";
echo "Andres Alejandro Vaca pero sin ser echo()";

/**B) Muestra tu nombre y edad concatenando dos cadenas de texto almacenadas en las variables
 * $nombre y $edad.
 */

echo "<br></br>";
$nombre = "Andres";
$edad = 20;
echo "Me llamo " . $edad . " y tengo " . $nombre . " años";

/**C) Haz una suma de las variables x, e, y, y muestra el resultado por la pantalla */
echo "<br></br>";

$x = 1;
$e = 4;
$y = 10;

$resultado = $x + $e + $y;
echo("El resultado es " . $resultado);
echo "<br></br>";

/**D) Usando lo anterior, si el resultado es mayor que 10, muestra con un <p> 
 * El número es mayor que 10. De lo contrario, muestra un párrafo con el texto 
 * tachado que el número es menor que 10. */

if($resultado > 10){
    echo "<p>El numero es mayor que 10</p>";
}else{
    echo"<p>El numero es menor que 10</p>";
}

echo "<br></br>";

/**E) Crea un array y muestra todos los elementos de la misma en un <ul> y cada uno de ellos en su correspondiente <li> */

$colores = array("Rojo", "Azul", "Verde");

echo "<ul>";

foreach($colores as $color){
    echo "<li>" . $color . "</li>";
}
echo "</ul>";