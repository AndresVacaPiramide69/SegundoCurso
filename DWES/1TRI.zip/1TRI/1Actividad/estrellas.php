<?php
/**Pinta n líneas yendo de 1 a n estrellas en la última línea */

$num_lineas = 15;

for($i = 0; $i <= $num_lineas; $i++){

    for($j = 0; $j < $i; $j++){
        echo "*";
    }
    echo "<br></br>";
}

?>