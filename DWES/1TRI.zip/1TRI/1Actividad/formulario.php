<?php
$email = $_GET['email'];
$password = $_GET['pswd'];

echo "<p> Tu email es " . $email . " y tu contraseña es : ". $password . " </p>"
?>