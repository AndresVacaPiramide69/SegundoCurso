<?php

$array = array();
$array['Melon'] = "Sandia";
$array['Gabin'] = "JuanCharli";
$array['Clara'] = "Pablo";
$array['Sergio'] = "Andres";

echo "La clave Melon tiene de valor: " . var_dump($array['Clara']);
?>