<?php
    $arrayNumeros = array(5, 1, 8, 4, 0, 2);
    sort($arrayNumeros);

    print_r($arrayNumeros);
?>