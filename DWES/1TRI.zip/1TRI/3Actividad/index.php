<!DOCTYPE html>
<html lang="es">
<?php
include "components/head.php";
?>
<body>
    <?php
    include "components/nav.php";
    ?>
</body>
</html>