<?php

interface OfertasRepository
{
    public function getOfertas();

    public function saveOferta($ofertaNueva);

}