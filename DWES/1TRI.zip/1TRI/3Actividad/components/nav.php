<header>
    <nav>
        <h1>CPIFP Pirámide - Ofertas de Empleo</h1>
    </nav>
</header>