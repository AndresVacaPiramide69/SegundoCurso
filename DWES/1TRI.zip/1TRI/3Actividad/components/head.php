<head>
    <meta charset="UTF-8">
    <title>Ofertas de empleo</title>
    <link rel="stylesheet" src="/var/www/html/1TRI/3Actividad/styles/style.css">
</head>