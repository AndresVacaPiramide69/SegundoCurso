<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Practica</title>
</head>
<body>
    
<?php
include './clases/Coche.php';
include "templates/header.php";


$coche1 = new Coche('5259GFL', "Ford", 2008, 199934);
$coche2 = new Coche("5928KMW", "Peugeot", 2021, 45000);

$coches = [$coche1, $coche2];


echo "<ul>";
    foreach($coches as $coche){
        echo "<br>";
        echo "<li> Matricula: " . $coche->getMatricula() . "</li>";
        echo "<li> Marca: " . $coche->getMarca() . "</li>";
        echo "<li> Fecha: " . $coche->getFecha() . "</li>";
        echo "<li> Kilometros: " . $coche->getKIlometros() . "</li>";
    }
echo "</ul>";

?>
</body>
</html>