<header>
    <h1>Concesionario Pirámide</h1>
    <nav>
        <a href='index.php'>Coches</a>
        <a href='nuevo.php'>Nuevo</a>
    </nav>
</header>