<form action="index.php" method="get">
    <label for="kilometros">Kilometros</label>
    <input type="number" id="kilometros">
</form>