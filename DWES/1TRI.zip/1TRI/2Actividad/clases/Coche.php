<?php

class Coche
{

    private $matricula;
    private $marca;
    private $fecha;
    private $kilometros;

    public function __construct($matricula, $marca, $fecha, $kilometros) {
        $this->$matricula = $matricula;
        $this->$marca = $marca;
        $this->$fecha = $fecha;
        $this->$kilometros = $kilometros;
    }

    public function getMatricula(){
        return $this->$matricula;
    }

    public function getMarca(){
        return $this->$marca;
    }

    public function getFecha(){
        return $this->$fecha;
    }

    public function getKilometros(){
        return $this->$kilometros;
    }
}
